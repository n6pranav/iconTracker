from flask import Flask, render_template, request, jsonify, url_for
import json, os, requests

app = Flask(__name__)
DATA_FILE = "installs.json"
API_KEY = "0f62ca5335544c918bbdd45cc6e50f8a"

def load_data():
    return json.load(open(DATA_FILE)) if os.path.exists(DATA_FILE) else []

def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/data")
def data():
    return jsonify(load_data())

@app.route("/bulk_import", methods=["POST"])
def bulk_import():
    body = request.get_json()
    installs = load_data()
    success, failed = [], []
    for entry in body:
        r = requests.get("https://api.opencagedata.com/geocode/v1/json", params={"q": entry["address"], "key": API_KEY}).json()
        if r.get("results"):
            g = r["results"][0]["geometry"]
            item = {
                "institution": entry["institution"],
                "lat": g["lat"],
                "lng": g["lng"],
                "date": entry["date"]
            }
            installs.append(item)
            success.append(item)
        else:
            failed.append(entry)
    save_data(installs)
    return jsonify(success=success, failed=failed)

@app.route("/edit", methods=["POST"])
def edit():
    body = request.get_json()
    installs = load_data()
    i = int(body["index"])
    r = requests.get("https://api.opencagedata.com/geocode/v1/json", params={"q": body["address"], "key": API_KEY}).json()
    if r.get("results"):
        g = r["results"][0]["geometry"]
        installs[i] = {
            "institution": body["institution"],
            "lat": g["lat"],
            "lng": g["lng"],
            "date": body["date"]
        }
        save_data(installs)
    return jsonify(installs)

@app.route("/delete", methods=["POST"])
def delete():
    index = request.get_json()["index"]
    installs = load_data()
    if 0 <= index < len(installs):
        installs.pop(index)
        save_data(installs)
    return jsonify(installs)

if __name__ == "__main__":
    app.run(debug=True, port=5050)
